int f1(){
    return 12;
}

int f2(){
    return 14;
}


int f3(int a){
    return 14*a;
}
