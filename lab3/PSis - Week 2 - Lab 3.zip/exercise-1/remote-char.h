// TODO_1 
// declaration the struct corresponding to the exchanged messages

// TODO_2
//declaration of the FIFO location